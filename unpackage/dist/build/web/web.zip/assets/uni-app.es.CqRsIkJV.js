import{a9 as a,aa as s,ab as o,ac as r,ad as t}from"./index-C0FQHog4.js";function n(a,s){return"string"==typeof a?s:a}const e=r=>(t,n=o())=>{!a&&s(r,t,n)},i=e(r),c=e(t);export{i as a,c as o,n as r};
