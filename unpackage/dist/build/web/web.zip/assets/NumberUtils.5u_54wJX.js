const r={toFixedNumber(r,o){const t=parseFloat(r);if(isNaN(t))throw new Error("输入必须是可转换为数字的值");return parseFloat(t.toFixed(o))}};export{r as N};
